from core.blueprints.base_blueprint import BaseBlueprint

flamapy_bp = BaseBlueprint('flamapy', __name__, template_folder='templates')
